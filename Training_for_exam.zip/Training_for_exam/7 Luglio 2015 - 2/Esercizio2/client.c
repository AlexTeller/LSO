#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<fcntl.h>
#include<sys/socket.h>
#include<arpa/inet.h>

int main(){

  struct sockaddr_in indClient;
  indClient.sin_port=htons(7080);
  indClient.sin_addr.s_addr=htonl(INADDR_ANY);
  indClient.sin_family=AF_INET;

  struct stat info;
  int n,fileDes,fd;
  char *nomeFile=(char *)malloc(100*sizeof(char));
  char buffer[100];

  fd=socket(PF_INET,SOCK_STREAM,0);
    if(fd<0){
      perror("socket error \n");
      exit(-1);
    }

  if(connect(fd,(struct sockaddr *)&indClient,sizeof(indClient)) <0 ){
    perror("connect error \n");
    exit(-1);
  }

  printf("Inserisci il nome di un file\n");
  n=read(0,nomeFile,100);
  nomeFile[n]='\0';
  printf("Nome file acquisito: %s \n",nomeFile);



  if( (fileDes=open("ciao.txt",O_RDONLY) < 0) ){
    printf("Impossibile aprire il file ciao.txt");
    exit(-1);
  }

  write(fd,"ciao.txt",strlen("ciao.txt"));

    stat("ciao.txt",&info);
    printf("Dimensione file: %ld \n",info.st_size);

  char *app= malloc(100*sizeof(char));
  sprintf(app,"%ld",info.st_size);
  app[strlen(app)]='\0';

  write(fd,app,strlen(app));
  printf("Inviata al server la dimensione del file, ora invio contenuto \n");

  while( (n=read(fileDes,buffer,100)) > 0){
    buffer[n]='\0';
    write(fd,buffer,100);
    memset(buffer,0,100);
  }

  printf("Inviata al server contenuto del file\n");

  free(nomeFile);
  close(fileDes);
  return 0;
}
