#include<stdlib.h>
#include<stdio.h>
#include<sys/stat.h>
#include<sys/socket.h>
#include<sys/types.h>
#include <unistd.h>
#include <netinet/in.h>
#include <pthread.h>
#include <string.h>
#include <fcntl.h>


//non funziona correttamente: il server non crea il file e non si riesce a leggere quello
//che il client Invia
void *funzione(void *argomenti);

pthread_mutex_t semaforo = PTHREAD_MUTEX_INITIALIZER;

struct info{
  float dimTot;
  int sockDes;
};

struct info Param;

int main(){
  pthread_t tid;
  struct sockaddr_in indServer;
  indServer.sin_port=htons(7080);
  indServer.sin_addr.s_addr=htonl(INADDR_ANY);
  indServer.sin_family=AF_INET;
  Param.dimTot=0;

  int fd1,fd2,n;

    fd1=socket(PF_INET,SOCK_STREAM,0);
      if(fd1<0){
        perror("socket error \n");
        exit(-1);
      }

    if( bind(fd1,(struct sockaddr*)&indServer,sizeof(indServer)) < 0){
      perror("bind error \n");
      exit(-1);
    }

    if( (listen(fd1,100)) < 0){
      perror("listen error \n");
      exit(-1);
    }
    printf("Server on line, in attesa di connessioni \n");

    fd2=accept(fd1,NULL,NULL);
    if(fd2<0){
      perror("accept error \n");
      exit(-1);
    }
    printf("Connessione stabilita \n");
    Param.sockDes=fd2;

    if( (pthread_create(&tid,NULL,funzione,(void *)&Param)) <0){
      perror("errore creazione thread \n");
      exit(-1);
    }
    pthread_join(tid,NULL);

    close(fd2);
    close(fd1);
  return 0;
}


void *funzione(void *argomenti){
  printf("+ Nuovo thread %lu \n",pthread_self());
struct info *Parametri = (struct info *)argomenti;
  char *buffer = malloc(100*sizeof(char));
  char *nomeFile = malloc(100*sizeof(char));
  int n;
  float dim;

  n=read(Parametri->sockDes,nomeFile,100);
  nomeFile[n]='\0';
  int fileDes=open(nomeFile,O_WRONLY|O_CREAT|O_APPEND);
    fchmod(fileDes,S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH);
    if(fileDes<0){
      perror("errore creazione file \n");
      exit(-1);
    }
  n=read(Parametri->sockDes,buffer,100);
  buffer[n]='\0';
  dim=atoi(buffer);
  printf("dimensione letta %f \n",dim);

    pthread_mutex_lock(&semaforo);
        if(Parametri->dimTot+dim <= 419430400){
          Parametri->dimTot=+dim;
          while( (n=read(Parametri->sockDes,buffer,100)) > 0){
            buffer[n]='\0';
            write(fileDes,buffer,strlen(buffer));
            memset(buffer,0,100);
          }
        }
        else
          write(Parametri->sockDes,"Dimensione max superata \n",strlen("Dimensione max superata \n"));
    pthread_mutex_unlock(&semaforo);



  free(buffer);
  free(nomeFile);
}
