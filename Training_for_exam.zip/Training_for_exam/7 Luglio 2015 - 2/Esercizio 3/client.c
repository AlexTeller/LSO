#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/stat.h>
#include<sys/types.h>
#include <fcntl.h>
#include<signal.h>

//rendere il file globale in modo da leggere quando intercetto il segnale e non usare la variabile leggiDaFile
//variabili globali e prototipi di funzione
int leggiDaFile;
void sig_hand(int num_segnale);

int main(){
  signal(SIGUSR1,sig_hand);

  char *stringa = malloc(100*sizeof(char));
  int n,fd;
  leggiDaFile=0;
    int client_to_server;
   char *myfifo = "/tmp/client_to_server_fifo";

   int server_to_client;
   char *myfifo2 = "/tmp/server_to_client_fifo";

   /* write str to the FIFO */
  client_to_server = open(myfifo, O_WRONLY);
  server_to_client = open(myfifo2, O_RDONLY);

  printf("Connessione stabilita \n");
  sprintf(stringa,"%d\n",getpid());

  if(write(client_to_server,stringa,strlen(stringa)) <0 ){
    perror("errore scrittura su fifo per server \n");
    exit(-1);
  }
  printf("Ho inviato il pid al server %s \n",stringa);
  memset(stringa,0,100);
  printf("Digita una stringa \n");
  n=read(0,stringa,100);
  stringa[n]='\0';
  //printf("Stringa acquisita: %s \n",stringa);

  if(write(client_to_server,stringa,strlen(stringa)) <0 ){
    perror("errore scrittura stringa su fifo per server \n");
    exit(-1);
  }


      pause();//il client si mette in attesa di un segnale

      if(leggiDaFile!=0){
        fd=open(stringa,O_RDONLY); //apro il file in modalità lettura
          memset(stringa,0,100);
          printf("Stampa contenuto file %s \n",stringa);
          while(n=read(fd,stringa,100) > 0){
            stringa[n]='\0';
            write(1,stringa,n);
            write(1,"\n",strlen("\n"));
            memset(stringa,0,100);
          }
          close(fd); //chiudo il file
      }

free(stringa);
close(client_to_server);
close(server_to_client);

return 0;
}

void sig_hand(int num_segnale){
  if(num_segnale==SIGUSR1){
    printf("Ricevuto segnale SIGUSR1, avvio lettura da file \n");
    leggiDaFile=1;
  }
}
