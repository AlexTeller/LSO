#include<stdio.h>
#include<string.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<stdlib.h>
#include<dirent.h>
#include<unistd.h>
#include<signal.h>

#include <fcntl.h>

int sommaDimFileReg(char *stringa);

int main(){
   char *buffer = malloc(100*sizeof(char));
   char *app = malloc(100*sizeof(char));
   int filedes,somma,pid,n;
   mode_t permessi = S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH;
   int client_to_server;
   char *myfifo = "/tmp/client_to_server_fifo";

   int server_to_client;
   char *myfifo2 = "/tmp/server_to_client_fifo";

   /* create the FIFO (named pipe) */
   mkfifo(myfifo, 0666);
   mkfifo(myfifo2, 0666);

   /* open, read, and display the message from the FIFO */
   client_to_server = open(myfifo, O_RDONLY);
   server_to_client = open(myfifo2, O_WRONLY);

   printf("Stato server: attivo \n");
   somma=0;

     while(1){
       //lettura pid che viene inviato dal client
       n=read(client_to_server,buffer,100);


       buffer[n]='\0';
       pid=atoi(buffer);
       printf("Acquisito pid client: %d \n",pid);
       memset(buffer,0,100);

       n=read(client_to_server,buffer,100);

       printf("Ricevuto dal client: %s \n",buffer);

       buffer[n]='\0';


       filedes=open(buffer,O_WRONLY|O_TRUNC|O_CREAT);
       fchmod(filedes,permessi);
       if(filedes<0){
         printf("Errore apertura file %s \n",buffer);
         exit(-1);
       }
       somma=sommaDimFileReg(buffer);
       sprintf(app,"%d\n",somma);
       app[strlen(app)]='\0';
       if( (write(filedes,app,strlen(app))) <=0){
         perror("errore scrittura su file \n");
         exit(-1);
       }

       kill(pid,SIGUSR1); //invio il segnale sigusr1 a pid
       printf("Inviato segnale SIGUSR1 a %d \n",pid);
       memset(app,0,100);
       memset(buffer,0,100);
     }

  close(client_to_server);
  close(server_to_client);

  unlink(myfifo);
  unlink(myfifo2);
  free(buffer);
  free(app);
return 0;
}

int sommaDimFileReg(char *stringa){
  int somma=0;
  DIR * dr;
  struct dirent *dircurr;
  struct stat info;
  char path[2000],new_path[2000];
  getcwd(path,sizeof(path));

  dr=opendir(path);
    if(!dr){
      perror("errore apertura directory corrente \n");
      exit(-1);
    }

    while( (dircurr=readdir(dr))!=NULL){
      if(strcmp(dircurr->d_name,".")!=0 && strcmp(dircurr->d_name,"..")!=0 && strncmp(dircurr->d_name,stringa,strlen(stringa))==0){
        //controllo che il file che scansiono inizi per stringa = stringa
        // e che le directory siano diverse da . e ..
          memset(new_path,0,2000);
          strcat(new_path,path);
          strcat(new_path,"/");
          strcat(new_path,dircurr->d_name);
          printf("Processando %s \n",new_path);
          stat(new_path,&info);
            somma=somma+info.st_size;
      }
    }
    closedir(dr);
    return somma;
}
