#include<stdio.h>
#include<stdlib.h>
#include<sys/stat.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<string.h>
#include<dirent.h>

float dimFileInCurr(char *nomeFile);

int main(int argc, char *argv[]){
  char *input=malloc(100*sizeof(char));
  char *buffer=malloc(1000*sizeof(char));
  char *mess=malloc(100*sizeof(char));
  int fd,n;
  float dim=-1;
  struct sockaddr_in indClient;
  indClient.sin_port=htons(7777);
  indClient.sin_addr.s_addr=htonl(INADDR_ANY);
  indClient.sin_family=AF_INET;

  if(argc<2){
    perror("errore passaggio parametri. Terminazione \n");
    exit(-1);
  }
  //salvataggio stringa passata in input da riga di comando
  strcpy(input,argv[1]);
  input[strlen(input)]='\0';

  fd=socket(PF_INET,SOCK_STREAM,0);
    if(fd<0){
      perror("socket error \n");
      exit(-1);
    }

  if(connect(fd,(struct sockaddr *)&indClient,sizeof(indClient)) <0){
    perror("connect error \n");
    exit(-1);
  }
  printf("connessione stabilita \n");

  write(fd,input,strlen(input));
  strcpy(buffer,"iniziale");

    while(strcmp(buffer,"fine\n")!=0){
      memset(buffer,0,1000);
      memset(mess,0,100);

      n=read(fd,buffer,1000);
      buffer[n]='\0';
      //write(1,buffer,strlen(buffer));
      if(strcmp(buffer,"fine")==0){
        break;
      }
      //cerco nella directory corrente file con nome = buffer
      printf("Ricevuto file dal nome: %s \n",buffer);
      dim=dimFileInCurr(buffer);

      if(dim>=0)
        sprintf(mess,"Il file %s esiste, dimensione: %f \n",buffer,dim);
      else
        sprintf(mess,"Il file %s non è stato trovato\n",buffer);

      write(1,mess,strlen(mess));
    }

  close(fd);
  printf("Comunicazione interrotta \n");
  free(input);
  free(buffer);
  free(mess);
  return 0;
}

float dimFileInCurr(char *nomeFile){
  DIR * dr;
  struct dirent *dircurr;
  struct stat info;
  float ris=-1;
  dr=opendir(".");

    if(!dr){
      perror("errore apertura directory corrente \n");
      exit(-1);
    }

    while( (dircurr=readdir(dr))!=NULL){
        if(strcmp(dircurr->d_name,nomeFile)==0){
          stat(dircurr->d_name,&info);
          ris=info.st_size;
      }
    }
    closedir(dr);
    return ris;
}
