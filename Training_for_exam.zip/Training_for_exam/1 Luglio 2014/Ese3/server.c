#include<stdio.h>
#include<stdlib.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<string.h>
#include <dirent.h>

void scansiona(char *dir, int sock);

int main(){
  struct sockaddr_in indServer;
  indServer.sin_port=htons(7777);
  indServer.sin_addr.s_addr=htonl(INADDR_ANY);
  indServer.sin_family=AF_INET;

  int fd1,fd2,n;
  char *buffer = malloc(100*sizeof(char));

  fd1=socket(PF_INET,SOCK_STREAM,0);
    if(fd1<0){
      perror("socket error \n");
      exit(-1);
    }

    if( bind(fd1,(struct sockaddr *)&indServer,sizeof(indServer)) <0){
      perror("bind error \n");
      exit(-1);
    }

    if( (listen(fd1,100)) <0){
      perror("Listen error \n");
      exit(-1);
    }
    printf("Server in ascolto \n");

    fd2=accept(fd1,NULL,NULL);
      if(fd2<0){
        perror("accept error \n");
        exit(-1);
      }

      printf("Nuova connessione stabilita \n");
      n=read(fd2,buffer,100);
      buffer[n]='\0';


        scansiona(buffer,fd2);

      free(buffer);
      close(fd1);

  return 0;
}


void scansiona(char *dir, int sock){
  DIR *dr;
  struct dirent *dircurr;

  char path[2000],app[100];
    dr=opendir(dir);
      if(!dr){
        printf("Impossibile aprire la directory %s , passo alla directory corrente \n",dir);
        dr=opendir(".");
          if(!dr){
            perror("Impossibile aprire la directory corrente \n");
            exit(-1);
          }
      }

      while( (dircurr=readdir(dr))!=NULL ) {
        if(strcmp(dircurr->d_name,".")!=0 && strcmp(dircurr->d_name,"..")!=0){
          memset(path,0,2000);
          getcwd(path,sizeof(path));
          strcat(path,"/");
          strcat(path,dircurr->d_name);
          printf("Processando %s \n",path);


            memset(app,0,100);
            strcpy(app,dircurr->d_name);
            app[strlen(app)]='\0';
            write(sock,app,strlen(app));

        }
      }
      write(sock,"fine\n",strlen("fine\n"));
  close(sock);
  closedir(dr);
}
