#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>

void *scansiona(void *param);
void scansiona_ric(char *path);

pthread_mutex_t semaforo = PTHREAD_MUTEX_INITIALIZER;

int somma;
int sommaSub;
char *string;

int main(int argc, char *argv[]){

somma=0;
sommaSub=0;
string=malloc(100*sizeof(char));
  strcpy(string,argv[1]);
  string[strlen(string)]='\0';

pthread_t tid;

  DIR *dr;
  struct dirent *dircurr;
  struct stat info;

  dr=opendir(".");
  if(!dr){
    perror("errore apertura directory corrente - master thread \n");
    exit(-1);
  }

  while( (dircurr=readdir(dr))!=NULL){
    if(strcmp(dircurr->d_name,".")!=0 && strcmp(dircurr->d_name,"..")!=0){
    printf("Master thread processando %s \n",dircurr->d_name);
    stat(dircurr->d_name,&info);

    if(S_ISREG(info.st_mode)){
      pthread_mutex_lock(&semaforo); //acquisisco il mutex
      somma=somma+info.st_size;
      if(strstr(dircurr->d_name,string)!=NULL){
        sommaSub=sommaSub+info.st_size;
      }
      pthread_mutex_unlock(&semaforo);  //rilascio il mutex
    }

    if(S_ISDIR(info.st_mode)){
      if(pthread_create(&tid,NULL,scansiona,(void *)&dircurr->d_name)<0){
        perror("Main: errore pthread_create \n");
        exit(-1);
      }
      pthread_join(tid,NULL);
    }
  }
}
  closedir(dr);


  printf("Somma dimensioni file regolari della directory corrente e sottodir: %d \n",somma);
  printf("Somma dimensioni file regolari dircurr e sottodir con sottostringa (%s) : %d \n",string,sommaSub);
  free(string);
  return 0;
}


void *scansiona(void *param){
  char *cartella = (char *)param;

  DIR *dr;
  struct dirent *dircurr;
  struct stat info;
  char * path = malloc(1000*sizeof(char));
  printf("+ + + Nuovo thread: %lu \n",pthread_self());
  dr=opendir(cartella);

  if(!dr){
    perror("Impossibile aprire la directory corrente \n");
    exit(-1);
  }

  while( (dircurr=readdir(dr))!=NULL){
    if(strcmp(dircurr->d_name,".")!=0 && strcmp(dircurr->d_name,"..")!=0){
      memset(path,0,1000);
      strcpy(path,cartella);
      strcat(path,"/");
      strcat(path,dircurr->d_name);
      printf("Processando %s \n",path);
      stat(path,&info);
        if(S_ISREG(info.st_mode)){
          pthread_mutex_lock(&semaforo); //acquisisco il mutex
          somma=somma+info.st_size;
          if(strstr(dircurr->d_name,string)!=NULL){
            sommaSub=sommaSub+info.st_size;
          }
          pthread_mutex_unlock(&semaforo);  //rilascio il mutex
        }
        if(S_ISDIR(info.st_mode)){
          scansiona_ric(path);
        }
      }
    }
  closedir(dr);
  free(path);
  //pthread_exit(NULL);
}

void scansiona_ric(char *path){
  DIR *dr;
  struct dirent *dircurr;
  struct stat info;
  char * percorso = malloc(1000*sizeof(char));
  dr=opendir(path);
  if(!dr){
    perror("Impossibile aprire la directory corrente \n");
    exit(-1);
  }

  while( (dircurr=readdir(dr))!=NULL){
    if(strcmp(dircurr->d_name,".")!=0 && strcmp(dircurr->d_name,"..")!=0){
      memset(percorso,0,1000);
      strcpy(percorso,path);
      strcat(percorso,"/");
      strcat(percorso,dircurr->d_name);
      printf("Processando %s \n",percorso);
      stat(percorso,&info);

        if(S_ISREG(info.st_mode)){
          pthread_mutex_lock(&semaforo); //acquisisco il mutex
          somma=somma+info.st_size;
          if(strstr(dircurr->d_name,string)!=NULL){
            sommaSub=sommaSub+info.st_size;
          }
          pthread_mutex_unlock(&semaforo);  //rilascio il mutex
        }
        if(S_ISDIR(info.st_mode))
          scansiona_ric(percorso);
      }
    }
  closedir(dr);
  free(percorso);
}
