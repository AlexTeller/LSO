#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<unistd.h>

int creaSocket(int port);

int main(){
  int fd1,fd2,n;
  char *buffer=malloc(100*sizeof(char));

  struct sockaddr_in client;

  fd1=creaSocket(8010);

  int dim=(int)sizeof(client);
  fd2=accept(fd1,(struct sockaddr *)&client,&dim);
    if(fd2<0){
      perror("accept error \n");
      exit(-1);
    }
    printf("connessione stabilita \n");

    while(1){
      //leggo dal socket quello che il client scrive!
      n=read(fd2,buffer,100);
      buffer[n]='\0';

        if(strncmp(buffer,"MYIP",strlen("MYIP"))==0){
          printf("Invio al client l'indirizzo ip su cui è connesso \n");
          memset(buffer,0,100);
          sprintf(buffer,"%d\n",client.sin_addr.s_addr);
          buffer[strlen(buffer)]='\0';
          write(fd2,buffer,strlen(buffer));
        }

        if(strncmp(buffer,"MYPORT",strlen("MYPORT"))==0){
          printf("Invio al client il numero della porta su cui è connesso \n");
          memset(buffer,0,100);
          sprintf(buffer,"%d\n",client.sin_port);
          buffer[strlen(buffer)]='\0';
          write(fd2,buffer,strlen(buffer));
        }

        if(strncmp(buffer,"NEWPORT",strlen("NEWPORT"))==0){
          printf("comando ricevuto NEWPORT \n");
          char *buf2=malloc(100*sizeof(char));
          n=read(fd2,buf2,100);
            buf2[n]='\0';
            printf("Porta %s \n",buf2);

          memset(buffer,0,100);
          strcpy(buffer,"ACK ");
          strcat(buffer,buf2);
          buffer[strlen(buffer)]='\0';

          write(fd2,buffer,strlen(buffer));

          //chiudo i socket
          close(fd2);
          close(fd1);
          fd1=creaSocket(atoi(buf2));
            //dim=(int)sizeof(client);
            //fd2=accept(fd1,client,dim);
              fd2=accept(fd1,NULL,NULL);
              if(fd2<0){
                perror("new port accept error \n");
                exit(-1);
              }
              else
                printf("Connessione stabilita su nuova porta \n");
          free(buf2);
        }
      }

  free(buffer);
  close(fd2);
  close(fd1);
  return 0;
}

int creaSocket(int port){
  struct sockaddr_in indirizzo;
  indirizzo.sin_addr.s_addr=htonl(INADDR_ANY);
  indirizzo.sin_family=AF_INET;
  indirizzo.sin_port=htons(port);

  int fd=socket(PF_INET,SOCK_STREAM,0);
    if(fd<0){
      perror("socket error");
      exit(-1);
    }

  int controllo = bind(fd,(struct sockaddr *)&indirizzo,sizeof(indirizzo));
    if(controllo < 0){
      perror("bind error \n");
      exit(-1);
    }

  controllo = listen(fd,100);
    if(controllo<0){
      perror("listen error \n");
      exit(-1);
    }
  return fd;
}
