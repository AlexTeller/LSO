#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>

;

int main(){
  int sockDes,n,port;
  char buffer[200];

  struct sockaddr_in indClient;
  indClient.sin_port=htons(8010);
  indClient.sin_family=AF_INET;
  indClient.sin_addr.s_addr=htonl(INADDR_ANY);

  sockDes=socket(PF_INET,SOCK_STREAM,0);
    if(sockDes<0){
      perror("socket error \n");
      exit(-1);
    }

    if(connect(sockDes,(struct sockaddr *)&indClient,sizeof(indClient)) <0){
      perror("connect error \n");
      exit(-1);
    }

    printf("connessione stabilita\n");
    printf("comandi disponibili: MYIP | MYPORT | NEWPORT \n");
    printf("Digita un comando \n");
    n=read(0,buffer,100);
    buffer[n]='\0';

    if(strncmp(buffer,"NEWPORT",strlen("NEWPORT"))==0){
      //invio il comando new port
      write(sockDes,buffer,strlen(buffer));

      char *porta =malloc(100*sizeof(char));
      printf("digita il numero della porta che vuoi utilizzare\n");
      n=read(0,porta,100);
      porta[n]='\0';
      port=atoi(porta);
      //comunico la porta
      write(sockDes,porta,strlen(porta));

      //indClient.sin_port=htons(port);

      memset(buffer,0,100);
      free(porta);
    }
    else{
      write(sockDes,buffer,strlen(buffer));
      memset(buffer,0,100);
    }
    n=read(sockDes,buffer,100);
      buffer[n]='\0';

      write(1,buffer,strlen(buffer));
  close(sockDes);
  return 0;
}
