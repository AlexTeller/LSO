#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

pthread_mutex_t semaforo =PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t condizione = PTHREAD_COND_INITIALIZER;

void *produttore(void *param);
void *consumatore(void *param);

int condivisa;

int main(){
pthread_t tid;
condivisa=0;

  for(int i=1; i<=5; i++){
    if( (pthread_create(&tid,NULL,produttore,NULL)) <0 ){
      perror("errore pthread create produttore \n");
      exit(-1);
    }
  }

  for(int i=1; i<=5; i++){
    if( (pthread_create(&tid,NULL,consumatore,NULL)) <0 ){
      perror("errore pthread create consumatore \n");
      exit(-1);
    }
  }

printf("Stampa variabile condivisa: %d \n",condivisa);
  return 0;
}

void *produttore(void *param){

  pthread_mutex_lock(&semaforo);
    condivisa++;
    pthread_cond_signal(&condizione);
  pthread_mutex_unlock(&semaforo);

}

void *consumatore(void *param){
  pthread_mutex_lock(&semaforo);
    while(condivisa<=2){
      printf("Thread %lu - condizione falsa, attendo\n",pthread_self());
      pthread_cond_wait(&condizione,&semaforo);
    }
  condivisa--;
  pthread_mutex_unlock(&semaforo);
}
