#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>

void sig_handler(int num_segnale);
void funzione_figlio(int i);
int fileUno,fileDue;
int main(){

  signal(SIGUSR1,sig_handler);
  signal(SIGUSR2,sig_handler);

  pid_t pid;
  int processi[2];
  int fd;
  char *app=malloc(100*sizeof(char));

  for(int i=0; i<2; i++){

    if( (pid=fork()) < 0){
      perror("fork error \n");
      exit(-1);
    }

    if(pid > 0){//padre
      int n;
        if(i==0){
          memset(app,0,100);
          fd=open("figlio1.txt",O_RDONLY);
          n=read(fd,app,100);
          app[n]='\0';
          write(1,app,strlen(app));
          kill(SIGKILL,processi[i]);
          close(fd);
        }
        if(i==1){
          memset(app,0,100);
          fd=open("figlio2.txt",O_RDONLY);
          n=read(fd,app,100);
          app[n]='\0';
          write(1,app,strlen(app));
          kill(SIGKILL,processi[i]);
          close(fd);
        }
    }
      if(pid == 0){//figlio
        processi[i]=getpid();
          funzione_figlio(i);
          pause();
      }
  }
  free(app);
  return 0;
}

void sig_handler(int num_segnale){
  if(num_segnale==SIGUSR1)
    printf("Ricevuto segnale SIGUSR1\n");

  if(num_segnale==SIGUSR1)
    printf("Ricevuto segnale SIGUSR2\n");

  if(num_segnale==SIGKILL)
    printf("Ricevuto SIGKILL \n");
}

void funzione_figlio(int i){
  char app[100];
  mode_t permessi = S_IRWXU | S_IRUSR | S_IWUSR | S_IXUSR;
  if(i==0){ //FIGLIO UNO
    fileUno=open("figlio1.txt",O_WRONLY|O_CREAT|O_TRUNC);
    fchmod(fileUno,permessi);
    sprintf(app,"%d\n",getpid());
      write(fileUno,app,strlen(app));
      kill(getppid(),SIGUSR1);

  }

  if(i==1){ //FIGLIO DUE
    fileDue=open("figlio2.txt",O_WRONLY|O_CREAT|O_TRUNC);
    fchmod(fileDue,permessi);
    sprintf(app,"%d\n",getpid());
      write(fileDue,app,strlen(app));
      kill(getppid(),SIGUSR2);

  }
}
