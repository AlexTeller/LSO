#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<unistd.h>
#include<netinet/in.h>

int main() {
  struct sockaddr_in indClient;
  indClient.sin_addr.s_addr=htonl(INADDR_ANY);
  indClient.sin_port=htons(7770);
  indClient.sin_family=AF_INET;

  int fd,n;
  char *buffer=malloc(100*sizeof(char));

  fd=socket(PF_INET,SOCK_STREAM,0);
    if(fd<0){
      perror("socket error \n");
      exit(-1);
    }

    if(connect(fd,(struct sockaddr *)&indClient,sizeof(indClient)) <0){
      perror("connect error \n");
      exit(-1);
    }
  printf("Connessione stabilita \n");

  printf("Digita il nome di una directory \n");
  n=read(0,buffer,100);
  buffer[n]='\0';
  write(fd,buffer,n);
  memset(buffer,0,100);

  while( (n=read(fd,buffer,100))>0){
    buffer[n]='\0';
    write(1,buffer,n);
    memset(buffer,0,100);
  }

  printf("\nConnessione terminata \n");

  free(buffer);
  close(fd);
  return 0;
}
