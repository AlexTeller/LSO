#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/stat.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<dirent.h>
#include<string.h>

int main(){
  int fd1,fd2,n;
  char *buffer=malloc(100*sizeof(char));

  struct sockaddr_in indServer;
  indServer.sin_port=htons(7770);
  indServer.sin_family=AF_INET;
  indServer.sin_addr.s_addr=htonl(INADDR_ANY);

  fd1=socket(PF_INET,SOCK_STREAM,0);
    if(fd1<0){
      perror("Socket error \n");
      exit(-1);
    }

    if( bind(fd1,(struct sockaddr *)&indServer,sizeof(indServer)) < 0 ){
      perror("Bind error \n");
      exit(-1);
    }

    if( (listen(fd1,100))<0){
      perror("Listen error \n");
      exit(-1);
    }
    write(1,"Server in attesa di connessione \n",strlen("Server in attesa di connessione \n"));

    fd2=accept(fd1,NULL,NULL);
    if(fd2<0){
      perror("accept error \n");
    }

    write(1,"Nuova connessione \n",strlen("Nuova connessione \n"));

    n=read(fd2,buffer,100);
    buffer[n-1]='\0';


    DIR *dr;
    struct dirent *direntry;
    struct stat info;
    char path[2000];
    getcwd(path,sizeof(path));
    strcat(path,"/");
    strcat(path,buffer);

    dr=opendir(path);
    if(!dr){
      printf("Impossibile aprire la directory %s \n",path);
      memset(buffer,0,100);
      sprintf(buffer,"%d\n",-1);
      buffer[strlen(buffer)]='\0';
      write(fd2,buffer,strlen(buffer));
    }
    else{
      while( (direntry=readdir(dr))!=NULL){
        memset(buffer,0,100);
        printf("Processando %s \n",direntry->d_name);
        stat(direntry->d_name,&info);
        if(S_ISREG(info.st_mode)){
          strcpy(buffer,direntry->d_name);
          buffer[strlen(buffer)]='\0';
          write(fd2,buffer,strlen(buffer));
        }
      }
    }

    free(buffer);
    closedir(dr);
    close(fd2);
    close(fd1);
  return 0;
}
