#include<stdio.h>
#include<stdlib.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<signal.h>
#include<string.h>
#include<unistd.h>

void sig_handler(int num_segn);
void funzione_figlio(int i,int fd1,int fd2);

int main(){

  pid_t process[2];
  int fd[2];

  if(pipe(fd)<0){
    perror("pipe creation error \n");
    exit(-1);
  }

  signal(SIGUSR1,sig_handler);


  for(int i=0;i<2;i++){
      if( (process[i]=fork() ) < 0){
        perror("Fork error \n");
        exit(-1);
      }
        if(process[i] == 0){ //figlio
          funzione_figlio(i,fd[0],fd[1]);
        }
        else{
          if(i==1){ /*unico dubbio: in questo modo non sono sicuro di controllare bene
                se il padre ha ricevuto il segnale da entrambi i figli */
            kill(SIGKILL,process[0]);
            kill(SIGKILL,process[1]);
          }
        }
    }

  return 0;
}


void funzione_figlio(int i,int fd1, int fd2){
  int fd,n;
  char *buffer = malloc(100*sizeof(char));

  if(i==0){
    close(fd1); //questo processo chiude il descrittore per leggere dalla pipe
    fd=open("figlio1.txt",O_RDONLY);
        n=read(fd,buffer,100);
        buffer[n]='\0';
          if(n>0){
            if( write(fd2,buffer,strlen(buffer)) < 0){
              perror("errore scrittura su pipe \n");
              exit(-1);
            }
          }
        kill(SIGUSR1,getppid());
        pause();
      }

  if(i==1){
    close(fd2); //chiudo il descrittore per scrivere sulla pipe
    fd=open("figlio2.txt",O_WRONLY|O_CREAT|O_TRUNC);
    fchmod(fd,S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH);
    n=read(fd1,buffer,100); // legge dalla pipe
      if(n<=0){
        perror("errore lettura su pipe \n");
        exit(-1);
      }
      buffer[n]='\0';
      if (write(fd,buffer,strlen(buffer)) <0){
        perror("processo 2 errore scrittura su file \n");
        exit(-1);
      }
      kill(SIGUSR1,getppid());
      pause();
  }
free(buffer);
}

void sig_handler(int num_segn){
  if(num_segn==SIGUSR1)
    printf("Intercettato %d\n",num_segn);
}
