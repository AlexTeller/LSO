#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include<string.h>
#include <pthread.h>

void *funzione(void *args);
int i;
pthread_mutex_t semaforo = PTHREAD_MUTEX_INITIALIZER;

struct info{
	int uno;
	int due;
	int index;
};
struct info param;

int main(int argc, char *argv[]){

mode_t permessi=S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
int k=10;
pthread_t tid[10];

	if(argc<3){
		perror("errore passaggio parametri \n");
		exit(-1);
		}

	param.uno=open(argv[1],O_RDONLY);
		if(param.uno<0){
			printf("Impossibile aprire file %s \n",argv[1]);
			exit(-1);
		}

	param.due=open(argv[2],O_WRONLY|O_TRUNC|O_CREAT);
		if(param.due<0){
			printf("Impossibile aprire file %s \n",argv[2]);
			exit(-1);
		}
			fchmod(param.due,permessi);

			for(int i=0; i<k; i++){
				pthread_mutex_lock(&semaforo);
					param.index=i;
				pthread_mutex_unlock(&semaforo);

				if( pthread_create(&tid[i],NULL,funzione,(void *)&param) <0){
					perror("errore pthread_create \n");
					exit(-1);
				}
			}


			for(int j=0; j<k; j++){
				pthread_join(tid[j],NULL);
				printf("Terminato thread %lu \n",tid[j]);
			}


close(param.uno);
close(param.due);
return 0;
}

void *funzione(void *args){
	printf("Thread %lu - faccio cose\n",pthread_self());
	struct info *parametri = (struct info*)args;
	char *buffer=malloc(1000*sizeof(char));
	char *app=malloc(100*sizeof(char));
	int n,num;
		pthread_mutex_lock(&semaforo);

		n=read(parametri->uno,buffer,100);
			buffer[n]='\0';

			num=buffer[parametri->index] - '0';
			sprintf(app,"%d\n",num);
			lseek(parametri->due,(off_t)parametri->index+1,SEEK_CUR);
			write(parametri->due,app,strlen(app));

		pthread_mutex_unlock(&semaforo);

	free(buffer);
	free(app);
}
