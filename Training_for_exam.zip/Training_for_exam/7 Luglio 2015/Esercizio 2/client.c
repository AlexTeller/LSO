#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<malloc.h>
#include<string.h>

int main(){

struct sockaddr_in mioIndirizzo;
mioIndirizzo.sin_port=htons(6809);
mioIndirizzo.sin_addr.s_addr=htonl(INADDR_ANY);
mioIndirizzo.sin_family=AF_INET;

int fd,n;
char *buffer = malloc(100*sizeof(char));
char *stringa = malloc(100*sizeof(char));
fd=socket(PF_INET,SOCK_STREAM,0);

  if(fd<0){
    perror("socket error \n");
    exit(-1);
  }

  if( connect(fd,(struct sockaddr*)&mioIndirizzo, sizeof(mioIndirizzo)) < 0){
    perror("connect error \n");
    exit(-1);
  }

  printf("Connessione stabilita, Digita una stringa\n");
  n=read(0,stringa,100);
  stringa[n]='\0';
  printf("Hai digitato: %s \n",stringa);
  sprintf(buffer,"%d",getpid());
  strcat(buffer," ");
  strcat(buffer,stringa);
  buffer[strlen(buffer)]='\0';

  write(fd,buffer,strlen(buffer));


free(stringa);
free(buffer);
close(fd);
  return 0;
}
