#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<malloc.h>
#include<string.h>
#include<pthread.h>
#include<fcntl.h>
#include <sys/stat.h>

pthread_mutex_t semaforo = PTHREAD_MUTEX_INITIALIZER;
void *funzione(void *param);

struct info{
  int fileDes;
  int sockDes;
};
struct info param;

int main(){

mode_t permessi=S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;

int fd1,fd2,n,fd;
pthread_t tid;

struct sockaddr_in indServer;

indServer.sin_port=htons(6809);
indServer.sin_family=AF_INET;
indServer.sin_addr.s_addr=htonl(INADDR_ANY);

fd1=socket(PF_INET,SOCK_STREAM,0);
  if(fd1<0){
    perror("errore socket \n");
    exit(-1);
  }

  if( (bind(fd1,(struct sockaddr *)&indServer,sizeof(indServer)) ) < 0 ){
    perror("errore bind \n");
    exit(-1);
  }

  if( (listen(fd1,100)) < 0){
    perror("errore listen \n");
    exit(-1);
  }

  fd=open("condiviso.txt",O_WRONLY|O_RDONLY|O_APPEND|O_CREAT);
  fchmod(fd,permessi);
  param.fileDes=fd;
  while(1){
  fd2=accept(fd1,NULL,NULL);
    param.sockDes=fd2;
    if(fd2 < 0){
      perror("accept error \n");
      exit(-1);
    }
    pthread_create(&tid,NULL,funzione,(void *)&param);
  }
close(fd2);
close(fd1);
return 0;
}

void *funzione(void *param){
  struct info *Parametri = (struct info *)param;
  char *mess = malloc(100*sizeof(char));
  int n;
  n=read(Parametri->sockDes,mess,100);
  mess[n]='\0';
  pthread_mutex_lock(&semaforo);
  write(Parametri->fileDes,mess,n);
  pthread_mutex_unlock(&semaforo);
  free(mess);
  printf("Sono il thread %lu - ho scritto sul file, ora termino \n",pthread_self());
  pthread_exit(NULL);
}
