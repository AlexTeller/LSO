#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<dirent.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<unistd.h>

void scansiona(char *path,int *numFile,int *totDim,int *numDir);

int main(int argc, char *argv[]){

  if(argc!=2){
    perror("Errore passaggio parametri \n");
    exit(-1);
  }

  int numero=0,dimensioni=0,numeroDir=0;
  scansiona(argv[1],&numero,&dimensioni,&numeroDir);

  printf("Numero file regolari  incontrati: %d \n",numero);
  printf("Dimensione totale file incontrati: %d \n",dimensioni);
  printf("Numero sottodirectory incontrate: %d \n",numeroDir);
return 0;
}

void scansiona(char *path,int *numFile,int *totDim,int *numDir){
    DIR *dr;
    pid_t pid;
    //int regolari=0,dimensioni=0;
    dr=opendir(path);
    if(!dr){
      printf("Impossibile aprire la directory %s \n",path);
      exit(-1);
    }

    int pipa[2];
    struct dirent *dircurr;
    struct stat info;
    char *percorso =malloc(1000*sizeof(char));
    int my_dir=0;
    int my_reg=0;
    int my_dim=0;

      while( (dircurr=readdir(dr))!=NULL ){
        if(strcmp(dircurr->d_name,".")!=0 && strcmp(dircurr->d_name,"..")!=0){
          memset(percorso,0,1000);
          strcat(percorso,path);
          strcat(percorso,"/");
          strcat(percorso,dircurr->d_name);
          printf("Analizzando %s \n",percorso);
          stat(percorso,&info);

          if(S_ISREG(info.st_mode)){
            my_reg++;
            my_dim=my_dim+info.st_size;
          }

          if(S_ISDIR(info.st_mode)){
            my_dir++;

            if(pipe(pipa)<0){
              perror("errore creazione pipe \n");
              exit(-1);
            }
            int figlio_num_file=0;
            int figlio_num_dir=0;
            int figlio_totale=0;

            pid=fork();
              if(pid<0){
                perror("errore fork \n");
                exit(-1);
              }
              if(pid==0){//figlio
                close(pipa[0]);
                scansiona(percorso,&figlio_num_file,&figlio_totale,&figlio_num_dir);
                write(pipa[1],&figlio_num_file,sizeof(int));
                write(pipa[1],&figlio_totale,sizeof(int));
                write(pipa[1],&figlio_num_dir,sizeof(int));
                exit(0);
              }
              if(pid>0){//padre
                close(pipa[1]);
                read(pipa[0],&figlio_num_file,sizeof(int));
                read(pipa[0],&figlio_totale,sizeof(int));
                read(pipa[0],&figlio_num_dir,sizeof(int));
                my_reg=my_reg+figlio_num_file;
                my_dim=my_dim+figlio_totale;
                my_dir=my_dir+figlio_num_dir;
              }
          }
        }
      }
  closedir(dr);
  free(percorso);
  *numFile=*numFile+my_reg;
  *totDim=*totDim+my_dim;
  *numDir=*numDir+my_dir;
}
