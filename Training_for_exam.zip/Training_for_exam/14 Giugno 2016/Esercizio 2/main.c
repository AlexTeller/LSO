#include <stdio.h>
#include <stdlib.h>
#include "lista.h"
#include <unistd.h>
#include <string.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pthread.h>

void *scansiona(void *param);
void scansiona_dir(char *path);

pthread_mutex_t semaforo = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t condizion = PTHREAD_COND_INITIALIZER;
int n=0; //numero di thread terminati

 struct param{
   char percorso[1000];
   Lista l;
 };
struct param parametri;

int main(){
  int cont = 0; //numero di thread creati

  parametri.l=NULL;
  char cwd[100];
  char path[1000];
  DIR * dr;
  struct dirent *dircurr;
  struct stat info;
  pthread_t tid;
  getcwd(cwd,sizeof(cwd));

  dr = opendir(cwd);
    if(!dr){
      perror("errore opendir \n");
      exit(-1);
    }

  while((dircurr=readdir(dr))!=NULL){
    if( strcmp(dircurr->d_name,".")!=0 && strcmp(dircurr->d_name,"..")!=0){
      strcpy(path,cwd);
      strcat(path,"/");
      strcat(path,dircurr->d_name);
      lstat(path,&info);
      printf("++ Processando %s \n",path);

      if(S_ISREG(info.st_mode)){
        pthread_mutex_lock(&semaforo);
        parametri.l=insTesta(parametri.l,path);
        pthread_mutex_unlock(&semaforo);
      }

      if(S_ISDIR(info.st_mode) ){
        strcpy(parametri.percorso,path);

              if(pthread_create(&tid,NULL,scansiona,(void *)&parametri) < 0 ){
                perror("errore crazione thread \n");
                exit(-1);
              }
              cont++; //aggiorno il numero di thread creati
      }

      memset(path,0,1000);
    }
  }
  //pthread_join(tid,NULL);

closedir(dr);
  //attendo la terminazione dei thread creati
    pthread_mutex_lock(&semaforo);   /*printf("\ncount: %d\n",count);*/
        while(n!=cont)
          pthread_cond_wait(&condizion,&semaforo);
    pthread_mutex_unlock(&semaforo);

    printf("+++ Stampa lista file regolari +++\n");
    stampa(parametri.l);
return 0;
}

void *scansiona(void *param){
struct param *parametri = (struct param *)param;
DIR * dr;
struct dirent * dircurr;
struct stat info;
char path[1000];
pthread_t tid;

  dr=opendir(parametri->percorso);
  if(!dr){
    perror("errore apertura directory \n");
    exit(-1);
  }

  while((dircurr=readdir(dr))!=NULL){
    if( strcmp(dircurr->d_name,".")!=0 && strcmp(dircurr->d_name,"..")!=0){
      strcpy(path,parametri->percorso);
      strcat(path,"/");
      strcat(path,dircurr->d_name);
      printf("Nel thread, processando %s \n",path);
        lstat(path,&info);

          if(S_ISREG(info.st_mode)){
            pthread_mutex_lock(&semaforo);
            parametri->l=insTesta(parametri->l,path);
            pthread_mutex_unlock(&semaforo);
          }

          if(S_ISDIR(info.st_mode)){
            scansiona_dir(path);
          }
      memset(path,0,100);
    }
  }
  closedir(dr);
  pthread_mutex_lock(&semaforo);
       n++; //aggiorno il numero di thread terminati
   pthread_mutex_unlock(&semaforo);
   pthread_cond_signal(&condizion);
}

void scansiona_dir(char *path){

    int err;char new_path[1000];DIR *dp;struct dirent *dirp;struct stat info;

    dp=opendir(path);   /**/if(dp==NULL){printf("Error opendir: %s\n",path);perror("");exit(1);}
    while((dirp=readdir(dp))!=NULL){
        strcpy(new_path,path);
        strcat(new_path,"/");
        strcat(new_path,dirp->d_name);
        err=lstat(new_path,&info);  /**/if(err==-1){printf("Error lstat file: %s\n",dirp->d_name);perror("");}
        if(S_ISDIR(info.st_mode)){
            if(strcmp(dirp->d_name,".")!=0 && strcmp(dirp->d_name,"..")!=0) {/**/printf("dir:%s\n",new_path);scansiona_dir(new_path);}
        }
        else if(S_ISREG(info.st_mode)){
            pthread_mutex_lock(&semaforo);
                parametri.l=insTesta(parametri.l,dirp->d_name);/*aggiungi nome file e somma dimensione*/
            pthread_mutex_unlock(&semaforo);
        }
    }
    closedir(dp);
}
