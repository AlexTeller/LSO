#include "lista.h"
#include <unistd.h>
#include <malloc.h>
#include <string.h>

Lista allocaNodo(){
  Lista L = NULL;
  L=malloc(sizeof(struct nodo));
  L->info=(char*)malloc(1000*sizeof(char));
  L->next=NULL;
  return L;
}

Lista insTesta(Lista Head, char parola[]){
  if(Head!=NULL){
    Lista App = allocaNodo();
    strcpy(App->info,parola);
    App->next=Head;
    Head=App;
  }
  else{
    Head=allocaNodo();
    strcpy(Head->info,parola);
  }
  return Head;
}

void stampa(Lista Head){
  while(Head!=NULL){
    write(1,Head->info,strlen(Head->info));
    write(1,"\n",strlen("\n"));

    Head=Head->next;
  }
}
