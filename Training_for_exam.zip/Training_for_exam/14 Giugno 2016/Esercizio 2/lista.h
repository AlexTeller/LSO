#ifndef lista_h
#define lista_h



struct nodo{
  char *info;
  struct nodo* next;
};
typedef struct nodo* Lista;

Lista allocaNodo();
Lista insTesta(Lista Head,char parola[]);
void stampa(Lista Head);

#endif
